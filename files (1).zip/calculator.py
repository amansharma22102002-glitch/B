"""
Basic GUI Calculator
=====================
A simple calculator built with Python's Tkinter library.

Features:
    - Equation display area showing the expression and result
    - Clickable buttons for digits (0-9) and operations (+, -, *, /)
    - Clear button (C) to reset the display
    - Equals button (=) to evaluate the expression

Author: (your name)
Learning Outcomes: Core Python, Tkinter, VS Code, GitHub, App Development
"""

import tkinter as tk

# ---------------------------------------------------------------------------
# Core application class
# ---------------------------------------------------------------------------
class Calculator:
    def __init__(self, root):
        self.root = root
        self.root.title("Basic Calculator")
        self.root.resizable(False, False)
        self.root.configure(bg="#1e1e1e")

        # Holds the current expression as a string, e.g. "12+7"
        self.expression = ""

        # StringVar drives the text shown on the display
        self.display_text = tk.StringVar(value="0")

        self._build_display()
        self._build_buttons()

    # -----------------------------------------------------------------
    # UI construction
    # -----------------------------------------------------------------
    def _build_display(self):
        """Creates the equation/result display area at the top."""
        display_frame = tk.Frame(self.root, bg="#1e1e1e")
        display_frame.pack(fill="both", padx=10, pady=(15, 5))

        display = tk.Entry(
            display_frame,
            textvariable=self.display_text,
            font=("Consolas", 28, "bold"),
            bd=0,
            bg="#1e1e1e",
            fg="#ffffff",
            justify="right",
            state="readonly",
            readonlybackground="#1e1e1e",
            insertontime=0,
        )
        display.pack(fill="both", ipady=20)

    def _build_buttons(self):
        """Creates the numeric keypad and operator buttons."""
        button_frame = tk.Frame(self.root, bg="#1e1e1e")
        button_frame.pack(padx=10, pady=10)

        # (label, row, col, colspan, button_type)
        buttons = [
            ("C", 0, 0, 1, "clear"),
            ("(", 0, 1, 1, "op"),
            (")", 0, 2, 1, "op"),
            ("/", 0, 3, 1, "op"),

            ("7", 1, 0, 1, "num"),
            ("8", 1, 1, 1, "num"),
            ("9", 1, 2, 1, "num"),
            ("*", 1, 3, 1, "op"),

            ("4", 2, 0, 1, "num"),
            ("5", 2, 1, 1, "num"),
            ("6", 2, 2, 1, "num"),
            ("-", 2, 3, 1, "op"),

            ("1", 3, 0, 1, "num"),
            ("2", 3, 1, 1, "num"),
            ("3", 3, 2, 1, "num"),
            ("+", 3, 3, 1, "op"),

            ("0", 4, 0, 2, "num"),
            (".", 4, 2, 1, "num"),
            ("=", 4, 3, 1, "equals"),
        ]

        colors = {
            "num": {"bg": "#333333", "fg": "#ffffff", "active": "#4d4d4d"},
            "op": {"bg": "#ff9500", "fg": "#ffffff", "active": "#ffb143"},
            "clear": {"bg": "#a83232", "fg": "#ffffff", "active": "#c94242"},
            "equals": {"bg": "#2e8b57", "fg": "#ffffff", "active": "#37a76a"},
        }

        for (label, row, col, colspan, btype) in buttons:
            style = colors[btype]
            btn = tk.Button(
                button_frame,
                text=label,
                font=("Consolas", 18, "bold"),
                width=4 if colspan == 1 else 9,
                height=2,
                bd=0,
                bg=style["bg"],
                fg=style["fg"],
                activebackground=style["active"],
                activeforeground="#ffffff",
                command=lambda l=label: self.on_button_click(l),
            )
            btn.grid(
                row=row, column=col, columnspan=colspan,
                padx=4, pady=4, sticky="nsew",
            )

    # -----------------------------------------------------------------
    # Button logic
    # -----------------------------------------------------------------
    def on_button_click(self, label):
        if label == "C":
            self.clear()
        elif label == "=":
            self.calculate()
        else:
            self.append_to_expression(label)

    def append_to_expression(self, value):
        self.expression += str(value)
        self.display_text.set(self.expression)

    def clear(self):
        self.expression = ""
        self.display_text.set("0")

    def calculate(self):
        try:
            # Evaluate the mathematical expression safely.
            result = eval(self.expression, {"__builtins__": {}}, {})
            self.display_text.set(str(result))
            self.expression = str(result)
        except ZeroDivisionError:
            self.display_text.set("Error: Div by 0")
            self.expression = ""
        except Exception:
            self.display_text.set("Error")
            self.expression = ""


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------
def main():
    root = tk.Tk()
    Calculator(root)
    root.mainloop()


if __name__ == "__main__":
    main()
